package com.designhub.app.login;

import android.os.Bundle;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.designhub.app.R;

/**
 * تصميم مظلم Dark Mode أنيق
 * كود مبسط لعرض التصميم فقط - يحتاج ربط حقيقي مع نظام المصادقة قبل الاستخدام الفعلي.
 */
public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_style_003);

        TextInputEditText etEmail = findViewById(R.id.tilEmail);
        TextInputEditText etPassword = findViewById(R.id.tilPassword);
        MaterialButton btnLogin = findViewById(R.id.btnLogin);

        btnLogin.setOnClickListener(v -> {
            // TODO: استبدل هذا بمنطق تسجيل الدخول الحقيقي (مثلاً عبر Retrofit + Backend)
            Toast.makeText(this, "جارٍ تسجيل الدخول...", Toast.LENGTH_SHORT).show();
        });
    }
}
